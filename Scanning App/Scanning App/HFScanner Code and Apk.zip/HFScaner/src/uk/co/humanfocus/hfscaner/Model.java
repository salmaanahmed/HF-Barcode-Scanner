package uk.co.humanfocus.hfscaner;

public class Model {
	String barcodeid;
	String name;
	String photograph;
	String address;
	String region;
	String city;
	String dob;
	public String getBarcodeid() {
		return barcodeid;
	}
	public void setBarcodeid(String barcodeid) {
		this.barcodeid = barcodeid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhotograph() {
		return photograph;
	}
	public void setPhotograph(String photograph) {
		this.photograph = photograph;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	
	

}
