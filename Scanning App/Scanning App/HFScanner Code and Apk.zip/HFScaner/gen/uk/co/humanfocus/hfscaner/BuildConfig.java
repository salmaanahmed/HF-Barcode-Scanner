/** Automatically generated file. DO NOT MODIFY */
package uk.co.humanfocus.hfscaner;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}